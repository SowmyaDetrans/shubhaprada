<?php

echo  "hi";
?>